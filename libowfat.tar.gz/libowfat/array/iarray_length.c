#include "iarray.h"

size_t iarray_length(iarray* ia) {
  return ia->len;
}
