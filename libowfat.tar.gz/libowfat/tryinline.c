static inline int foo(int bar) { return bar+1; }
